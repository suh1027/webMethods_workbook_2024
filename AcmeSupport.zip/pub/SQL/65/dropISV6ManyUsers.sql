drop user ISV6 cascade;
drop user isv61 cascade;
drop user isv62 cascade;
drop user isv63 cascade;
drop user isv64 cascade;
drop user isv65 cascade;
drop user isv66 cascade;
drop user isv67 cascade;
drop user isv68 cascade;
drop user isv69 cascade;
drop user isv610 cascade;
drop user isv611 cascade;
drop user isv612 cascade;
drop user isv613 cascade;
drop user isv614 cascade;
drop user isv615 cascade;
drop user isv616 cascade;
drop user isv617 cascade;
drop user isv618 cascade;


